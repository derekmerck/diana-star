import attr
from .requester import Requester

attr.s
class MontageRequester(Requester):
    pass