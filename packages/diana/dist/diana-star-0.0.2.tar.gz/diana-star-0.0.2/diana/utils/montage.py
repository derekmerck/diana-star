import attr
from .requester import Requester

attr.s
class MontageRequester(Requester):
    raise NotImplementedError
    pass